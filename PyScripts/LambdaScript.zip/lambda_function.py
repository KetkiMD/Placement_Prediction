import json
import base64
import io
import pandas as pd
import boto3
from utils import process_dbda,placement_process,process_registration,process_master,process_dac,merge_dfs


def lambda_handler(event, context):
    try:
        # Retrieve course type
        course_type = event.get("course_type", "Unknown")
        month = event.get("month", "Unknown")
        year = event.get("year", "Unknown")

        # Retrieve the files dictionary with fixed keys
        files = event.get("files", {})

        required_keys = ["master", "result", "placement", "registration"]
        if not all(key in files and files[key] for key in required_keys):
            return {
                "statusCode": 400,
                "body": "Missing one or more required files"
        }

        # Decode file contents
        decoded_files = {key: base64.b64decode(files[key]) for key in required_keys}

        # Now you can access files using:
        master_file_content = decoded_files["master"]
        result_file_content = decoded_files["result"]
        placement_file_content = decoded_files["placement"]
        registration_file_content = decoded_files["registration"]

        print('Files received')
        result_file_content = io.BytesIO(result_file_content)
        master_file_content = io.BytesIO(master_file_content)
        placement_file_content = io.BytesIO(placement_file_content)
        registration_file_content = io.BytesIO(registration_file_content)


        if course_type == 'DBDA':
            res_df = process_dbda(result_file_content)
        else:
            res_df = process_dac(result_file_content)

        plac_df = placement_process(placement_file_content)
        reg_df = process_registration(registration_file_content)
        master_df = process_master(master_file_content)
        print('All files preprocessed successfully')


        final_df = merge_dfs(result=res_df,placement=plac_df,master=master_df,registration=reg_df,month=month,year = year)

        final_name = course_type+month+str(year)+'.csv'
        bucket_name = "ingestionbucketforglue"
        upload_path = course_type.lower()
        try:
            s3_client = boto3.client("s3")

            # Convert DataFrame to CSV in-memory
            csv_buffer = io.StringIO()
            final_df.to_csv(csv_buffer, index=False)
            s3_key = f"{upload_path}/{final_name}"

            # Upload to S3
            s3_client.put_object(
                Bucket=bucket_name,
                Key=s3_key,
                Body=csv_buffer.getvalue()
            )

            print( f"File {final_name} successfully uploaded to {bucket_name} at{s3_key}")

        except Exception as e:
            print(str(e))

        return {
            "statusCode": 200,
            "message": f"Files processed successfully for {course_type}",
            "file_names": list(decoded_files.keys())
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": str(e)
        }
