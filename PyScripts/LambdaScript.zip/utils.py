import pandas as pd


def merge_column_headers(file_path):
    df = pd.read_excel(file_path, header=[0, 1])

    # Combine the column headers from the first and second rows
    df.columns = [
        f"{col[0]}{col[1]}" for col in df.columns
    ]

    return df


def rename_column(col):
    if 'PRN' in col:
        return 'PRN'
    elif 'Data Collection and DBMS' in col:
        if 'Theory' in col:
            return 'DBMSTheory'
        elif 'Lab' in col:
            return 'DBMSLab'
        elif 'Total' in col:
            return 'DBMSTotal'
        elif 'Status' in col:
            return 'DBMSStatus'
    elif 'Object Oriented Programming with Java 8' in col:
        if 'Theory' in col:
            return 'JavaTheory'
        elif 'Lab' in col:
            return 'JavaLab'
        elif 'Total' in col:
            return 'JavaTotal'
        elif 'Status' in col:
            return 'JavaStatus'
    elif 'Python & R Programming' in col:
        if 'Theory' in col:
            return 'PythonRTheory'
        elif 'Lab' in col:
            return 'PythonRLab'
        elif 'Total' in col:
            return 'PythonRTotal'
        elif 'Status' in col:
            return 'PythonRStatus'
    elif 'Advance Analytics using Statistics' in col:
        if 'Theory' in col:
            return 'StatsTheory'
        elif 'Lab' in col:
            return 'StatsLab'
        elif 'Total' in col:
            return 'StatsTotal'
        elif 'Status' in col:
            return 'StatsStatus'
    elif 'Data Visualization - Analysis and Reporting' in col:
        if 'Theory' in col:
            return 'DataVizTheory'
        elif 'Lab' in col:
            return 'DataVizLab'
        elif 'Total' in col:
            return 'DataVizTotal'
        elif 'Status' in col:
            return 'DataVizStatus'
    elif 'Big Data Technologies' in col:
        if 'Theory' in col:
            return 'BigDataTheory'
        elif 'Lab' in col:
            return 'BigDataLab'
        elif 'Total' in col:
            return 'BigDataTotal'
        elif 'Status' in col:
            return 'BigDataStatus'
    elif 'Linux Programming and Cloud Computing' in col:
        if 'Theory' in col:
            return 'LinuxCloudTheory'
        elif 'Lab' in col:
            return 'LinuxCloudLab'
        elif 'Total' in col:
            return 'LinuxCloudTotal'
        elif 'Status' in col:
            return 'LinuxCloudStatus'
    elif 'Practical Machine Learning' in col:
        if 'Theory' in col:
            return 'MLTheory'
        elif 'Lab' in col:
            return 'MLLab'
        elif 'Total/100' in col:
            return 'MLTotal'
        elif 'Status' in col:
            return 'MLStatus'
        elif '800' in col:
            return 'Total'
        elif '%' in col:
            return 'Percentage'
        elif 'Grade' in col:
            if 'Apti' in col:
                return 'AptiGrade'
            elif 'Project' in col:
                return 'ProjectGrade'
            else:
                return 'Grade'
        elif 'Result' in col:
            return 'Result'
    return col


def process_dbda(excel_file):
    df = merge_column_headers(excel_file)
    df.rename(columns=lambda col: rename_column(col), inplace=True)
    return df


def placement_process(filecontent) -> pd.DataFrame:
    column_mapping = {
        'PRN': 'PRN',
        'Group': 'Group',
        'Company placed':'Company_Name',
        'company': 'Company_Name',
        'Company Name': 'Company_Name',
        'CCP ID': 'CCP_ID',
        'CTC': 'Package',
        'Campus or Self Placed': 'C_S',
        'Technology': 'TECHSTACK',
        'center': 'CENTER',
        'Company Placed': 'Company_Name'
    }
    df = pd.read_excel(filecontent)
    print('Processing')
    # Drop completely empty columns
    df = df.dropna(axis=1, how='all')

    # Ensure correct header alignment
    df.columns = df.columns.str.strip()

    # Rename columns based on mapping
    df = df.rename(columns=column_mapping)

    # Keep only required columns if they exist
    required_columns = ['PRN', 'Company_Name', 'Package']
    existing_columns = [col for col in required_columns if col in df.columns]
    df = df[existing_columns]

    # Add missing columns with empty values
    for col in required_columns:
        if col not in df.columns:
            df[col] = ''

    return df


def process_registration(reg_content):
    """
    Cleans and standardizes column names in the DataFrame.

    Args:
        df (pd.DataFrame): Input DataFrame with raw column names.

    Returns:
        pd.DataFrame: DataFrame with standardized column names.
    """
    df = pd.read_excel(reg_content)
    # Define a mapping for column renaming
    column_mapping = {
        'C-DAC Form Number':'form_number',
        'Timestamp': 'timestamp',
        'CCAT Form Number': 'form_number',
        'CCAT Rank': 'CCATrank',
        'Select your Course': 'course',
        'Date of Birth (eg. 1 June 1995)': 'dob',
        'Date of Birth': 'dob',
        'School Name': 'school_name',
        '10th Std Percentage': '10th_percentage',
        '10 Std Percentage': '10th_percentage',
        '12th Std College Name': '12th_college',
        ' 12th Std College Name': '12th_college',
        '12th Std Percentage': '12th_percentage',
        'Diploma College Name': 'diploma_college',
        'Diploma Percentage (as appeared on final Diploma)': 'diploma_percentage',
        'Diploma Percentage': 'diploma_percentage',
        'Graduation Degree': 'grad_degree',
        'Graduation (Write the Degree)': 'grad_degree',
        'Branch': 'branch',
        'Graduation University Name': 'grad_university',
        'Graduation Percentage': 'grad_percentage',
        'Graduation Percentage ': 'grad_percentage',
        'Aggregate Percentage of all Semesters (write without  %  sign & if CGPA then convert it into percentage)': 'aggregate_percentage',
        'Graduation Percentage as appeared on your Degree / Provisional Certificate (write without  %  sign & if CGPA then convert it into percentage)': 'grad_percentage_certificate',
        'PG /  PGD Certification, if any': 'pg_certification',
        'PG University Name': 'pg_university',
        'PG Percentage (write without  %  sign & if CGPA then convert it into percentage)': 'pg_percentage',
        'PG Percentage ': 'pg_percentage',
        'Have you done Pre CCAT?': 'pre_ccat',
        'Have you done PreCCAT?': 'pre_ccat',
        'If yes, then from which institute:': 'pre_ccat_institute',
        'You have done PreCCAT from which institute': 'pre_ccat_institute',
        '1st Instalment Paid': 'instalment_1_paid',
        'Have you paid the 2nd Instalment': 'instalment_2_paid',
        'All documents are uploaded in the link provided by C-DAC': 'documents_uploaded',
        'Diploma Marksheet in PDF format (Any one) ( Max 1 MB )': 'diploma_marksheet',
        'Skype ID': 'skype_id',
        'Percentage of Marks ( write without  %  sign )(if CGPA then Convert it into percentage )': 'percentage_marks',
        'Select Your Degree Options': 'degree_options',
        # Add other mappings if needed
    }

    # Rename columns using the mapping
    df = df.rename(columns=column_mapping)

    # Add missing columns with default values to maintain uniform structure
    standardized_columns = [
        'timestamp', 'form_number', 'CCATrank', 'course', 'dob', 'school_name',
        '10th_percentage', '12th_college', '12th_percentage', 'diploma_college',
        'diploma_percentage', 'grad_degree', 'branch', 'grad_university',
        'grad_percentage', 'aggregate_percentage', 'pg_certification',
        'pg_university', 'pg_percentage', 'pre_ccat', 'pre_ccat_institute',
        'instalment_1_paid', 'instalment_2_paid', 'documents_uploaded',
        'diploma_marksheet', 'skype_id'
    ]

    for col in standardized_columns:
        if col not in df.columns:
            df[col] = None  # Add missing columns with default value `None`

    # Retain only standardized columns in the defined order
    df = df[standardized_columns]

    columns_to_drop = [
        'timestamp', 'school_name',
        '12th_college', 'grad_university',
        'pg_certification', 'pg_university',
        'pre_ccat_institute', 'instalment_1_paid',
        'instalment_2_paid', 'documents_uploaded',
        'diploma_marksheet', 'skype_id',
        'aggregate_percentage', 'diploma_college'
    ]

    # Drop specified columns if they exist in the DataFrame
    df = df.drop(columns=[col for col in columns_to_drop if col in df.columns])
    return df


def process_master(content):
    """
    Reads a excek file and extracts only 'form_number' and 'PRN' columns.
    
    
    
    Returns:
        pd.DataFrame: A DataFrame with two columns: 'form_number' and 'PRN'.
    """
    try:
        # Read CSV file as strings to preserve formatting
        df = pd.read_excel(content, dtype=str)

        # Normalize column names (case-insensitive)
        df.columns = df.columns.str.lower()

        # Identify the relevant columns
        form_number_col = next((col for col in df.columns if "form no" in col), None)
        prn_col = next((col for col in df.columns if "prn" in col), None)

        # If both columns exist, create a new DataFrame
        if form_number_col and prn_col:
            return df[[form_number_col, prn_col]].rename(columns={form_number_col: "form_number", prn_col: "PRN"})

        # Handle missing columns
        missing_cols = [col for col in ["form_number", "PRN"] if col not in [form_number_col, prn_col]]
        raise ValueError(f"Missing columns: {', '.join(missing_cols)} in file {content}")

    except Exception as e:
        print(f"Error processing {content}: {e}")
        return pd.DataFrame(columns=["form_number", "PRN"])  # Return empty DataFrame on failure



import pandas as pd


def process_dac(res_content):
    df = pd.read_excel(res_content, header=[0, 1])
    # Merge the first two header rows to create meaningful column names
    df.columns = [
        f"{str(col[0]).strip()}_{str(col[1]).strip()}" if isinstance(col, tuple) and col[0] and col[1] else str(
            col[1]).strip()
        if isinstance(col, tuple) and col[1] else str(col[0]).strip()
        for col in df.columns
    ]

    # Define the expected subject columns
    expected_columns = [
        "PRN", "OS_Theory", "OS_Lab", "OS_Total", "OS_Status",
        "CPP_Theory", "CPP_Lab", "CPP_Total", "CPP_Status",
        "Java_Theory", "Java_Lab", "Java_Total", "Java_Status",
        "DSA_Theory", "DSA_Lab", "DSA_Total", "DSA_Status",
        "DBT_Theory", "DBT_Lab", "DBT_Total", "DBT_Status",
        "WPT_Theory", "WPT_Lab", "WPT_Total", "WPT_Status",
        "WB_Java_Theory", "WB_Java_Lab", "WB_Java_Total", "WB_Java_Status",
        "DotNet_Theory", "DotNet_Lab", "DotNet_Total", "DotNet_Status",
        "SDLC_Theory", "SDLC_Lab", "SDLC_Total", "SDLC_Status",
        "Total800", "Percentage", "Grade", "Result", "Apti_EC_Grade", "Project_Grade"
    ]

    # Define the column mapping to standardize names
    column_mapping = {
        "unnamed: 0_level_0_prn": "PRN",
        "operating system theory_40": "OS_Theory",
        "operating system lab_60": "OS_Lab",
        "operating system total_100": "OS_Total",
        "operating system status": "OS_Status",
        "core java theory_40": "Java_Theory",
        "core java lab_60": "Java_Lab",
        "core java total_100": "Java_Total",
        "core java status": "Java_Status",
        "algorithms and data structures (using java) theory_40": "DSA_Theory",
        "algorithms and data structures (using java) lab_60": "DSA_Lab",
        "algorithms and data structures (using java) total_100": "DSA_Total",
        "algorithms and data structures (using java) status": "DSA_Status",
        "web programming technologies theory_40": "WPT_Theory",
        "web programming technologies lab_60": "WPT_Lab",
        "web programming technologies int_60": "WPT_Lab",
        "web programming technologies total_100": "WPT_Total",
        "web programming technologies status": "WPT_Status",
        "database technologies theory_40": "DBT_Theory",
        "database technologies lab_60": "DBT_Lab",
        "database technologies total_100": "DBT_Total",
        "database technologies status": "DBT_Status",
        "microsoft .net technologies theory_40": "DotNet_Theory",
        "microsoft .net technologies lab_60": "DotNet_Lab",
        "microsoft .net technologies total_100": "DotNet_Total",
        "microsoft .net technologies status": "DotNet_Status",
        "software engineering theory_40": "SDLC_Theory",
        "software engineering lab_60": "SDLC_Lab",
        "software engineering total_100": "SDLC_Total",
        "software engineering status": "SDLC_Status",
        "advanced java theory_40": "WB_Java_Theory",
        "advanced java lab_60": "WB_Java_Lab",
        "advanced java total_100": "WB_Java_Total",
        "advanced java status": "WB_Java_Status",
        "total_800": "Total800",
        "total_%": "Percentage",
        "total_grade": "Grade",
        "total_result": "Result",
        "total_apti & ec grade": "Apti_EC_Grade",
        "total_project grade": "Project_Grade",
        "c++ programming_theory/40": "CPP_Theory",
        "c++ programming_lab/60": "CPP_Lab",
        "c++ programming_total/100": "CPP_Total",
        "c++ programming_status": "CPP_Status",
        "concepts of programming & operating system_theory/40": "OS_Theory",
        "concepts of programming & operating system_lab/60": "OS_Lab",
        "concepts of programming & operating system_total/100": "OS_Total",
        "concepts of programming & operating system_status": "OS_Status",
        "concepts of programming, operating system & software engineering_theory/40": "OS_Theory",
        "concepts of programming, operating system & software engineering_lab/60": "OS_Lab",
        "concepts of programming, operating system & software engineering_total/100": "OS_Total",
        "concepts of programming, operating system & software engineering_status": "OS_Status",
        "object oriented programming with java_theory/40": "Java_Theory",
        "object oriented programming with java_lab/60": "Java_Lab",
        "object oriented programming with java_total/100": "Java_Total",
        "object oriented programming with java_status": "Java_Status",
        "core java_theory/40": "Java_Theory",
        "core java_lab/60": "Java_Lab",
        "core java_total/100": "Java_Total",
        "core java_status": "Java_Status",
        "algorithms and data structures (using java)_theory/40": "DSA_Theory",
        "algorithms and data structures (using java)_lab/60": "DSA_Lab",
        "algorithms and data structures (using java)_total/100": "DSA_Total",
        "algorithms and data structures (using java)_status": "DSA_Status",
        "web programming technologies_theory/40": "WPT_Theory",
        "web programming technologies_lab/60": "WPT_Lab",
        "web programming technologies_int/60": "WPT_Lab",
        "web programming technologies_total/100": "WPT_Total",
        "web programming technologies_status": "WPT_Status",
        "database technologies_theory/40": "DBT_Theory",
        "database technologies_lab/60": "DBT_Lab",
        "database technologies_total/100": "DBT_Total",
        "database technologies_status": "DBT_Status",
        "web-based java programming_theory/40": "WB_Java_Theory",
        "web-based java programming_lab/60": "WB_Java_Lab",
        "web-based java programming_total/100": "WB_Java_Total",
        "web-based java programming_status": "WB_Java_Status",
        "microsoft .net technologies_theory/40": "DotNet_Theory",
        "microsoft .net technologies_lab/60": "DotNet_Lab",
        "microsoft .net technologies_total/100": "DotNet_Total",
        "microsoft .net technologies_status": "DotNet_Status",
        "software development methodologies_theory/40": "SDLC_Theory",
        "software development methodologies_lab/60": "SDLC_Lab",
        "software development methodologies_total/100": "SDLC_Total",
        "software development methodologies_status": "SDLC_Status",
        "total_800": "Total800",
        "total_600": "Total800",
        "web-based java programming_total/600": "Total800",
        "web-based java programming_total/800": "Total800",
        "total_%": "Percentage",
        "web-based java programming_%": "Percentage",
        "total_grade": "Grade",
        "web-based java programming_grade": "Grade",
        "total_result": "Result",
        "web-based java programming_result": "Result",
        "total_apti & ec grade": "Apti_EC_Grade",
        "web-based java programming_apti & ec grade": "Apti_EC_Grade",
        "total_project grade": "Project_Grade",
        "web-based java programming_project grade": "Project_Grade"
    }

    # Apply the mapping
    df.rename(columns=lambda x: column_mapping.get(x.lower(), x), inplace=True)

    # Ensure all expected columns exist, adding missing ones with empty values
    for col in expected_columns:
        if col not in df.columns:
            df[col] = None  # Assign missing columns as empty

    # Calculate Total800 as the sum of all subject totals
    subject_total_columns = [col for col in df.columns if "Total" in col and col not in ["Total800"]]
    df["Total800"] = df[subject_total_columns].apply(pd.to_numeric, errors='coerce').sum(axis=1)

    # Reorder columns to match expected structure
    df = df[expected_columns]
    return df


def merge_dfs(result, placement, master, registration, month, year):
    result['PRN'] = result['PRN'].astype(str)
    placement['PRN'] = placement['PRN'].astype(str)
    result_placement = result.merge(placement,
                                    on='PRN',  # Specify the column to join on
                                    how='left',  # Join type
                                    )
    master = master.dropna(subset=['form_number'])
    registration = registration.dropna(subset=['form_number'])

    master['form_number'] = master['form_number'].apply(lambda x: str(int(x)) if isinstance(x, float) else str(x))
    registration['form_number'] = registration['form_number'].apply(
        lambda x: str(int(x)) if isinstance(x, float) else str(x))
    master_registration = master.merge(
        registration,
        on='form_number',
        how='inner'
    )
    # Ensure PRN columns are strings and consistent
    result_placement['PRN'] = result_placement['PRN'].astype(str).str.strip()
    master_registration['PRN'] = master_registration['PRN'].astype(str).str.strip()

    # Merge the DataFrames on PRN
    final_merged_data = master_registration.merge(
        result_placement,
        on='PRN',
        how='left',
    )
    final_merged_data['year'] = year
    final_merged_data['month'] = month

    print('Merged Successfully!!!')
    return final_merged_data
